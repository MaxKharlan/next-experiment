Small synthetic delivery/billing classification example for testing the interface.
Each JSONL row ends in the reference label. These are separate rows in four splits.
This is an integration example, not a benchmark or proof of a fine-tuning failure.
